# tvingM-v18
 티빙 애드온 for Kodi18

- DRM 실시간 채널(ocn, super action 등)이 설정한 화질보다 낮게 재생될때
  InputStream Adaptive 애드온 설정에서 Ignore Display Resolution 활성화
- (필수) Tving 홈페이지 기기등록 화면에서 PC로 등록된 기기 필요 (1회)

# 변경사항
## Version 1.2.4 (2020.02.04)
- 특정 실행환경 오류 수정

## Version 1.2.3 (2020.02.02)
- 특정 실행환경 오류 수정

## Version 1.2.2 (2020.01.27)
- 즐겨찾기, 커스텀메뉴 사용자를 위한 로그인 방식 개선

## Version 1.2.1 (2019.12.30)
- 에피소드 다음페이지 조회 오류 수정
- 에피소드 회차순서 변경기능 추가(최신순->1회부터)
- VOD, 영화 기본 썸네일로 세로기준으로 변경

## Version 1.2.0 (2019.12.26)
- DRM 영상 재생관련 오류 수정
- 무비 프리미엄 사용자를 위한 primium 영화 추가 옵션(설정) 추가

## Version 1.1.0 (2019.12.23)
- DRM 채널 지원 (ocn, super action 등)
- 월정액영화 Lite 카테고리 추가

## Version 1.0.0 (2019.12.17)
- 실시간채널 지원
- VOD 지원 drm채널 재생 미지원
