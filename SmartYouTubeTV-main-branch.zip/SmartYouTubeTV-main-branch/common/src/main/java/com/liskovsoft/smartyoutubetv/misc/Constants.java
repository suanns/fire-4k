package com.liskovsoft.smartyoutubetv.misc;

public class Constants {
    public static final String ACTION_CLEAR_CACHE = "android.intent.action.CLEAR_CACHE";
}
