package com.liskovsoft.smartyoutubetv.fragments;

public interface BrowserFragment extends GenericFragment {
}
