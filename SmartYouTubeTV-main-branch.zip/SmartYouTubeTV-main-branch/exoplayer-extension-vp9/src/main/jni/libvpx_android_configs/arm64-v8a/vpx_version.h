// This file is generated. Do not edit.
#define VERSION_MAJOR  1
#define VERSION_MINOR  8
#define VERSION_PATCH  2
#define VERSION_EXTRA  "23-g50d1a4aa7"
#define VERSION_PACKED ((VERSION_MAJOR<<16)|(VERSION_MINOR<<8)|(VERSION_PATCH))
#define VERSION_STRING_NOSP "v1.8.2-23-g50d1a4aa7"
#define VERSION_STRING      " v1.8.2-23-g50d1a4aa7"
