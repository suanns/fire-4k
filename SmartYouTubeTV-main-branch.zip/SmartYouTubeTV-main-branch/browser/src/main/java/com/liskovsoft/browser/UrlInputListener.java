package com.liskovsoft.browser;

public interface UrlInputListener {
}
