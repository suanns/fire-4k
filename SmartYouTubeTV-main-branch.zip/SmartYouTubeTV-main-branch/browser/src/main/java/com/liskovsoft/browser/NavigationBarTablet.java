package com.liskovsoft.browser;

import android.content.Context;
import android.util.AttributeSet;

/**
 * TODO: not implemented yet
 */
public class NavigationBarTablet extends NavigationBarBase {
    public NavigationBarTablet(Context context) {
        super(context);
    }

    public NavigationBarTablet(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public NavigationBarTablet(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
