# tvingM-v18
 티빙 애드온 for Kodi18

###
# 1.6.1 이후 부터는 저장소를 통해서만 업데이트 됩니다.
* [Korea OTT Package for Kodi 18 (public)-18.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v18_public.zip)
   - 설치가능 애드온 : 티빙, 웨이브, 왓챠, 스포티비나우
* [Korea OTT Package for Kodi 19 (public)-19.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v19_public.zip)
   - 설치가능 애드온 : 티빙, 웨이브, 왓챠, 스포티비나우
   - 현재 코디19는 알파2 지원(알파1 오류)
###


# 공통
- DRM 실시간 채널(ocn, super action 등)이 설정한 화질보다 낮게 재생될때
  InputStream Adaptive 애드온 설정에서
  Ignore Display Resolution 활성화
  또는 스트림수동 선택후 재생화면 옵션에서 수동변경해볼것
- (필수) Tving 홈페이지 기기등록 화면에서 PC로 등록된 기기 필요 (1회)


# 변경사항

## Version 1.6.1 (2020.09.08)
- 특정스킨 오류 수정

## Version 1.6.0 (2020.08.31)
- 로그인 처리변경 (세션정보 파일처리)

## Version 1.5.2 (2020.07.23)
- 검색기능 오류 수정

## Version 1.5.1 (2020.06.14)
- vod 최근시청내역 바로보기 옵션 추가

## Version 1.5.0 (2020.04.13)
- 애드온 버전 통일
- 내부폴더명 변경 (이전버전 애드온은 삭제후 설치하세요)
- info 정보 추가
- 화질관련 옵션 정리

## Version 1.3.0 (2020.04.08)
- 성능개선을 위한 일부구조 변경

## Version 1.2.5 (2020.03.15)
- VOD 및 영화 포스터 썸네일(가로세로) 옵션 추가

## Version 1.2.4 (2020.02.04)
- 특정 실행환경 오류 수정

## Version 1.2.3 (2020.02.02)
- 특정 실행환경 오류 수정

## Version 1.2.2 (2020.01.27)
- 즐겨찾기, 커스텀메뉴 사용자를 위한 로그인 방식 개선

## Version 1.2.1 (2019.12.30)
- 에피소드 다음페이지 조회 오류 수정
- 에피소드 회차순서 변경기능 추가(최신순->1회부터)
- VOD, 영화 기본 썸네일로 세로기준으로 변경

## Version 1.2.0 (2019.12.26)
- DRM 영상 재생관련 오류 수정
- 무비 프리미엄 사용자를 위한 primium 영화 추가 옵션(설정) 추가

## Version 1.1.0 (2019.12.23)
- DRM 채널 지원 (ocn, super action 등)
- 월정액영화 Lite 카테고리 추가

## Version 1.0.0 (2019.12.17)
- 실시간채널 지원
- VOD 지원 drm채널 재생 미지원
